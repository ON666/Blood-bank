<?php
// Database connection parameters
$servername = "localhost"; // Change this to your database server name
$username = "your_username"; // Change this to your database username
$password = "your_password"; // Change this to your database password
$database = "your_database"; // Change this to your database name

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Bank</title>
    <style>
        /* CSS styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        label {
            font-weight: bold;
        }
        select, input[type="text"] {
            margin-bottom: 10px;
            padding: 8px;
            width: 100%;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Find Blood Donors</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
            <label for="blood_group">Select Blood Group:</label>
            <select name="blood_group" id="blood_group">
                <option value="">Select Blood Group</option>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
            </select>
            <label for="city">Select City:</label>
            <select name="city" id="city">
                <option value="">-- Select District --</option>
                <option value="">-- Select District --</option>
	<option value="Amritsar" >Amritsar</option>
	<option value="Barnala" >Barnala</option>
	<option value="Bathinda" >Bathinda</option>
	<option value="Faridkot" >Faridkot</option>
	<option value="Fatehgarh Sahib" >Fatehgarh Sahib</option>
	<option value="Fazilka" >Fazilka</option>
	<option value="Firozpur" >Firozpur</option>
	<option value="Gurdaspur" >Gurdaspur</option>
	<option value="Hoshiarpur" >Hoshiarpur</option>
	<option value="Jalandhar" >Jalandha</option>
	<option value="Kapurthala" >Kapurthala</option>
	<option value="Ludhiana" >Ludhiana</option>
	<option value="MalerKotla" >Maler Kotla</option>
	<option value="Mansa" >Mansa</option>
	<option value="Moga" >Moga</option>
	<option value="Pathankot" >Pathankot</option>
	<option value="Patiala" >Patiala</option>
	<option value="Rupnagar" >Rupnagar</option>
	<option value="Sangrur" >Sangrur</option>
	<option value="SAS nagar" >SAS nagar</option>
	<option value="SBS Nagar" >SBS Nagar</option>
	<option value="Shri Muktsar Sahib" >Shri Muktsar Sahib</option>
	<option value="Tarn Taran" >Tarn Taran</option>
                <!-- Add your city options here -->
            </select>
            <button type="submit">Search</button>
        </form>
        <?php
        // PHP code to fetch data from the database and display
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $blood_group = $_POST["blood_group"];
            $city = $_POST["city"];

            // Assume $conn is the database connection object
            // Replace the query with your actual database query
            $query = "SELECT * FROM donors WHERE blood_group = '$blood_group' AND city = '$city'";
            $result = mysqli_query($conn, $query);

            if (mysqli_num_rows($result) > 0) {
                echo "<h3>Available Donors:</h3>";
                echo "<table>";
                echo "<tr><th>Name</th><th>Blood Group</th><th>City</th><th>Contact Number</th></tr>";
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr><td>".$row["name"]."</td><td>".$row["blood_group"]."</td><td>".$row["city"]."</td> <td>".$row["contact_no"]."</td> </tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No donors available for the selected criteria.</p>";
                echo "<p>You can request for blood donation:</p>";
                echo "<form method='post' action='request_blood.php'>";
                echo "<input type='hidden' name='blood_group' value='$blood_group'>";
                echo "<input type='hidden' name='city' value='$city'>";
                echo "<label for='name'>Your Name:</label>";
                echo "<input type='text' name='name' id='name' required>";
                echo "<label for='contact'>Contact Number:</label>";
                echo "<input type='text' name='contact' id='contact' required>";
                echo "<label for='request_blood_group'>Blood Group Needed:</label>";
                echo "<input type='text' name='request_blood_group' id='request_blood_group' value='$blood_group' readonly>";
                echo "<label for='request_city'>City:</label>";
                echo "<input type='text' name='request_city' id='request_city' value='$city' readonly>";
                echo "<button type='submit'>Request Blood</button>";
                echo "</form>";
            }
        }
        ?>
    </div>
</body>
</html>
