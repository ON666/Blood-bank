<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Form</title>
</head>
<body>
    <h2>Feedback Form</h2>
    <?php if(isset($_GET['status']) && $_GET['status'] == 'success'): ?>
        <p style="color: green;">Thank you for your feedback!</p>
    <?php endif; ?>
    <form action="process_feedback.php" method="post">
        <!-- Form fields -->
    </form>
</body>
</html>
