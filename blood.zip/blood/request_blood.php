<?php

$servername = "localhost"; // Change this to your database server name
$username = "your_username"; // Change this to your database username
$password = "your_password"; // Change this to your database password
$database = "your_database"; // Change this to your database name

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST["name"];
    $contact = $_POST["contact"];
    $blood_group = $_POST["blood_group"];
    $city = $_POST["city"];

    // Your SQL query to insert data into the database
    $query = "INSERT INTO requests (name, contact, blood_group, city) VALUES ('$name', '$contact', '$blood_group', '$city')";

    if (mysqli_query($conn, $query)) {
        echo "Request submitted successfully.";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>
