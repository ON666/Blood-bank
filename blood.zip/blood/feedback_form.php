<?php 
 //include header file
 include ('include/header.php');

 // Check if the form is submitted
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
   // Database connection
   $servername = "127.0.0.1"; // Change this to your MySQL server name
   $username = "root"; // Change this to your MySQL username
   $password = ""; // Change this to your MySQL password
   $dbname = "blood"; // Change this to your MySQL database name

   // Create connection
   $conn = new mysqli($servername, $username, $password, $dbname);

   // Check connection
   if ($conn->connect_error) {
	   die("Connection failed: " . $conn->connect_error);
   }

   // Retrieve form data
   $name = $_POST['name'];
   $email = $_POST['email'];
   $contact_no = $_POST['contact_no'];
   $feedback = $_POST['feedback'];


   // Insert data into the database
   $sql = "INSERT INTO feedback_form (name, email, contact_no,feedback) 
		   VALUES ('$name','$email', '$contact_no', '$feedback')";

   if ($conn->query($sql) === TRUE) {
	   echo "Thank you for your feedback";
   } else {
	   echo "Error: " . $sql . "<br>" . $conn->error;
   }

   // Close the database connection
   $conn->close();
 }
?>


<style>
	.size{
		min-height: 0px;
		padding: 60px 0 40px 0;
		
	}
	.form-container{
		background-color: white;
		border: .5px solid #eee;
		border-radius: 5px;
		padding: 20px 10px 20px 30px;
		-webkit-box-shadow: 0px 2px 5px -2px rgba(89,89,89,0.95);
-moz-box-shadow: 0px 2px 5px -2px rgba(89,89,89,0.95);
box-shadow: 0px 2px 5px -2px rgba(89,89,89,0.95);
	}
	.form-group{
		text-align: left;
	}
	h1{
		color: white;
	}
	h3{
		color: #e74c3c;
		text-align: center;
	}
	.red-bar{
		width: 25%;
	}
</style>
<div class="container-fluid red-background size">
	<div class="row">
		<div class="col-md-6 offset-md-3">
			<h1 class="text-center">Feedback</h1>
			<hr class="white-bar">
		</div>
	</div>
</div>
<div class="container size">
	<div class="row">
		<div class="col-md-6 offset-md-3 form-container">
					<h3>Write your feedback</h3>
					<hr class="red-bar">
					
          <!-- Error Messages -->

		  <form class="form-group" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
					<div class="form-group">
						<label for="fullname">Full Name</label>
						<input type="text" name="name" id="fullname" placeholder="Full Name" required pattern="[A-Za-z/\s]+" title="Only lower and upper case and space" class="form-control">
					</div><!--full name-->
				  
				    <div class="form-group">
						<label for="fullname">Email</label>
						<input type="text" name="email" id="email" placeholder="Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" title="Please write correct email" class="form-control">
					</div>
					<div class="form-group">
              <label for="contact_no">Contact No</label>
              <input type="text" name="contact_no" value="" placeholder="+91********" class="form-control" required pattern="^\d{10}$" title="10 numeric characters only" maxlength="10">
            </div><!--End form-group-->
			<div class="form-group">
    <label for="feedback">Message</label>
    <textarea name="feedback" id="feedback" placeholder="Write to us" rows="8" required pattern="[A-Za-z/\s]+" title="Only lower and upper case and space" class="form-control"></textarea>
</div>

              
             
			
					<div class="form-group">
						<button id="submit" name="submit" type="submit" class="btn btn-lg btn-danger center-aligned" style="margin-top: 20px;">Send Feedback</button>
					</div>
				</form>
		</div>
	</div>
</div>

<?php 
  //include footer file
  include ('include/footer.php');
?>